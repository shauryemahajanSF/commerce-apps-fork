/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError } from '@/scapi';
import { siteContext, type SiteContext } from '@salesforce/storefront-next-runtime/site-context';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';
import { cleanupTemporaryBaskets, createTemporaryBasket, addItemToBasket } from '../lib/api/basket-mutations.server';

/**
 * Server action that sweeps orphaned temp baskets, then creates a fresh
 * temporary basket and adds a single product item.
 *
 * Used by the PDP express buttons (`sfp.express()` → `onClick` → `prepareBasket`)
 * to stage a buy-now flow without touching the shopper's main basket.
 *
 * Cleanup runs first ("sweep-before-prep"). It's scoped to the current
 * `customerId` from the auth middleware — guests carry a `gcid`, registered
 * shoppers an `rcid`, so both paths sweep only their own orphans. The sweep is
 * best-effort; a failure is logged but does not block basket creation.
 *
 * POST body:
 *   productId: string (required)
 *   quantity:  string (required, parsed to int)
 *   inventoryId: string (optional)
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data({ success: false, error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);
    let productId: string | undefined;
    let quantityRaw: string | undefined;
    try {
        const formData = await request.formData();
        productId = formData.get('productId')?.toString();
        quantityRaw = formData.get('quantity')?.toString();
        const inventoryId = formData.get('inventoryId')?.toString();
        const currencyParam = formData.get('currency')?.toString();

        if (!productId || !quantityRaw) {
            return data({ success: false, error: 'productId and quantity are required' }, { status: 400 });
        }

        const quantity = parseInt(quantityRaw, 10);
        if (!Number.isFinite(quantity) || quantity <= 0) {
            return data({ success: false, error: 'Invalid quantity' }, { status: 400 });
        }

        const { customerId } = getAuth(context);
        if (customerId) {
            try {
                await cleanupTemporaryBaskets(context, customerId);
            } catch (error) {
                logger.warn('[sf-payments] temp-basket cleanup skipped', {
                    ...(error instanceof ApiError ? error.toJSON() : { message: String(error) }),
                });
            }
        }

        // Prefer the client-provided currency (what Elements is binding to). Fall
        // back to the resolved siteContext.currency so the temp basket matches
        // what the basket middleware would reprice it to anyway.
        const { currency: siteCurrency } = context.get(siteContext) as SiteContext;
        const currency = currencyParam || siteCurrency;
        const tempBasket = await createTemporaryBasket(context, currency);
        if (!tempBasket.basketId) {
            return data({ success: false, error: 'Temporary basket creation returned no basketId' }, { status: 500 });
        }

        const basket = await addItemToBasket(context, tempBasket.basketId, {
            productId,
            quantity,
            ...(inventoryId ? { inventoryId } : {}),
        });

        return { success: true, basket };
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[sf-payments] create-express-basket failed', {
            productId,
            quantity: quantityRaw,
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data(
            { success: false, error: isApiError ? error.body?.detail || error.message : String(error) },
            { status: isApiError ? error.status : 500 }
        );
    }
}
