/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import type { ShopperBasketsV2, ShopperCustomers, ShopperOrders } from '@/scapi';
/**
 * Payment gateway types supported by SF Payments.
 */
export type PaymentGateway = 'stripe' | 'adyen' | 'paypal';

/**
 * Payment method types (aligned with SCAPI payment method types).
 */
export type PaymentMethodType =
    | 'card'
    | 'paypal'
    | 'venmo'
    | 'applepay'
    | 'googlepay'
    | 'amazon_pay'
    | 'sepa_debit'
    | 'klarna'
    | 'ideal'
    | 'afterpay'
    | 'bancontact'
    | 'twint';

/**
 * Express payment usage modes — passed by surface wrappers (PDP, cart, checkout)
 * to ExpressButtons and PaymentSheet via props.
 */
export const EXPRESS_PAY_NOW = 0;
export const EXPRESS_BUY_NOW = 1;

/**
 * Payment method type constants
 */
export const PAYMENT_METHOD_TYPES = {
    CARD: 'card',
    PAYPAL: 'paypal',
    VENMO: 'venmo',
    APPLE_PAY: 'applepay',
    GOOGLE_PAY: 'googlepay',
    AMAZON_PAY: 'amazon_pay',
    SEPA_DEBIT: 'sepa_debit',
    KLARNA: 'klarna',
    IDEAL: 'ideal',
    AFTERPAY: 'afterpay',
    BANCONTACT: 'bancontact',
    TWINT: 'twint',
} as const;

/**
 * Payment gateway constants
 */
export const PAYMENT_GATEWAYS = {
    STRIPE: 'stripe',
    ADYEN: 'adyen',
    PAYPAL: 'paypal',
} as const;

/**
 * SDK confirm response codes. The SDK uses a ResponseCode enum internally
 * but does not export it, so consumers define their own constants.
 */
export const SDK_RESPONSE_CODE = {
    SUCCESS: 0,
    FAILURE: 1,
} as const;

/**
 * Setup future usage constants (for Stripe saved payments)
 */
export const SETUP_FUTURE_USAGE = {
    ON_SESSION: 'on_session',
    OFF_SESSION: 'off_session',
} as const;

// ─── Interfaces ──────────────────────────────────────────────────────────────

interface StripePaymentInstrument {
    paymentReference?: {
        gatewayProperties?: {
            stripe?: { clientSecret?: string };
        };
    };
}

interface AdyenPaymentInstrument {
    paymentReference?: {
        gatewayProperties?: {
            adyen?: { adyenPaymentIntent?: { resultCode?: string } };
        };
    };
}

/**
 * Address transformation interface
 */
interface AddressDetails {
    name?: string;
    address: {
        line1: string;
        line2?: string;
        city: string;
        state?: string;
        postalCode: string;
        country: string;
    };
    phone?: string;
}

interface TransformedAddress {
    firstName: string | null;
    lastName: string | null;
    address1: string;
    address2?: string | null;
    city: string;
    stateCode?: string;
    postalCode: string;
    countryCode: string;
    phone?: string | null;
}

/**
 * Privacy-shielded partial address the SDK emits in `onShippingAddressChange`.
 * Wallets (Google Pay / Apple Pay) redact name + street line until approval, so
 * only city / region / postal / country are present, and the keys are snake_case.
 */
export interface ExpressShippingAddressPartial {
    city?: string;
    state?: string;
    postal_code?: string;
    country?: string;
}

interface PaymentMethod {
    paymentMethodType: string;
    accountId: string;
}

interface PaymentMethodSetAccount {
    accountId: string;
    vendor: string;
}

/**
 * Shape returned to the SF Payments SDK from `onShippingAddressChange` and
 * `onShippingMethodChange` callbacks.
 */
export interface ExpressCallbackData {
    total: string;
    shippingMethods: ReturnType<typeof transformShippingMethods>;
    selectedShippingMethod: ReturnType<typeof transformShippingMethods>[number] | undefined;
    lineItems: Array<{ name: string; amount: string }>;
}

/**
 * Localized labels for the line items emitted to the SDK. Callers pass strings
 * that are already translated for the shopper's locale — this helper is pure
 * and does no i18n on its own.
 */
export interface ExpressCallbackLabels {
    subtotal: string;
    shipping: string;
    tax: string;
}

// ─── Functions ───────────────────────────────────────────────────────────────

/**
 * Returns the first Salesforce Payments instrument found in a basket or order.
 *
 * Note on the return type: SCAPI models both `Basket.paymentInstruments` and
 * `Order.paymentInstruments` as arrays of `OrderPaymentInstrument`, so we
 * reuse that schema for both halves of the union.
 */
export function getSFPaymentsInstrument(
    basketOrOrder: ShopperBasketsV2.schemas['Basket'] | ShopperOrders.schemas['Order']
): ShopperBasketsV2.schemas['OrderPaymentInstrument'] | ShopperOrders.schemas['OrderPaymentInstrument'] | undefined {
    return basketOrOrder?.paymentInstruments?.find((pi) => pi.paymentMethodId === 'Salesforce Payments');
}

/**
 * Returns the client secret from a payment instrument (e.g. Stripe PaymentIntent client_secret).
 */
export function getClientSecret(
    paymentInstrument:
        | ShopperBasketsV2.schemas['OrderPaymentInstrument']
        | ShopperOrders.schemas['OrderPaymentInstrument']
): string | undefined {
    return (paymentInstrument as StripePaymentInstrument | undefined)?.paymentReference?.gatewayProperties?.stripe
        ?.clientSecret;
}

/**
 * Returns the Adyen resultCode from a payment instrument after redirect completion.
 */
export function getAdyenResultCode(
    paymentInstrument:
        | ShopperBasketsV2.schemas['OrderPaymentInstrument']
        | ShopperOrders.schemas['OrderPaymentInstrument']
        | undefined
): string | undefined {
    return (paymentInstrument as AdyenPaymentInstrument | undefined)?.paymentReference?.gatewayProperties?.adyen
        ?.adyenPaymentIntent?.resultCode;
}

/**
 * Transform billing and shipping address details from payment provider format to basket format.
 *
 * Both addresses are required. Callers that may not have billing details
 * (e.g. express wallets like Apple Pay/Google Pay where billing may be
 * omitted) should explicitly pass shipping as billing at the call site.
 */
export function transformAddressDetails(
    billingDetails: AddressDetails,
    shippingDetails: AddressDetails
): { billingAddress: TransformedAddress; shippingAddress: TransformedAddress } {
    const transformSingleAddress = (addressDetails: AddressDetails): TransformedAddress => {
        const address: TransformedAddress = {
            firstName: null,
            lastName: null,
            address1: addressDetails.address.line1,
            address2: addressDetails.address.line2 || null,
            city: addressDetails.address.city,
            stateCode: addressDetails.address.state,
            postalCode: addressDetails.address.postalCode,
            countryCode: addressDetails.address.country,
            phone: addressDetails.phone || null,
        };

        // Last token → lastName; everything before → firstName. Single-token
        // names (e.g. "Madonna", "李") produce empty firstName, which is
        // valid per SCAPI's AddressModel — both name fields are optional.
        if (addressDetails.name) {
            const names = addressDetails.name.split(' ');
            address.firstName = names.slice(0, -1).join(' ');
            address.lastName = names.slice(-1).join(' ');
        }

        return address;
    };

    return {
        billingAddress: transformSingleAddress(billingDetails),
        shippingAddress: transformSingleAddress(shippingDetails),
    };
}

/**
 * Map the SDK's partial shipping-change payload to SCAPI's `OrderAddress`
 * shape. Skips name/line1 (not supplied pre-approval) and keeps the mapping
 * explicit so unexpected keys don't leak into the SCAPI request and trip its
 * strict decoder (rejects unknown properties with 400).
 */
export function transformExpressShippingAddressPartial(partial: ExpressShippingAddressPartial): {
    city?: string;
    stateCode?: string;
    postalCode?: string;
    countryCode?: string;
} {
    return {
        city: partial.city,
        stateCode: partial.state,
        postalCode: partial.postal_code,
        countryCode: partial.country,
    };
}

/**
 * Transform shipping methods from API format to express payment format.
 */
export function transformShippingMethods(
    shippingMethods: Array<{ id: string; name: string; description?: string; price: number }>,
    _basket: ShopperBasketsV2.schemas['Basket'],
    selectedId: string | null = null,
    sortSelected: boolean = true
): Array<{ id: string; name: string; classOfService?: string; amount: string }> {
    const methods = shippingMethods.map((method) => ({
        id: method.id,
        name: method.name,
        classOfService: method.description,
        amount: method.price?.toString(),
    }));

    if (sortSelected && selectedId) {
        methods.sort((m1, m2) => {
            if (m1.id === selectedId) return -1;
            if (m2.id === selectedId) return 1;
            return 0;
        });
    }

    return methods;
}

/**
 * Get the currently selected shipping method ID from basket or fallback to default.
 */
export function getSelectedShippingMethodId(
    basket: ShopperBasketsV2.schemas['Basket'],
    defaultShippingMethodId?: string
): string | undefined {
    return basket.shipments?.[0]?.shippingMethod?.id || defaultShippingMethodId;
}

/**
 * Validates current shipping method is still applicable.
 */
export function isShippingMethodValid(
    currentBasket: ShopperBasketsV2.schemas['Basket'],
    updatedShippingMethods: { applicableShippingMethods: Array<{ id: string }> }
): boolean {
    const currentShippingMethodId = currentBasket.shipments?.[0]?.shippingMethod?.id;
    if (!currentShippingMethodId) return false;

    return updatedShippingMethods.applicableShippingMethods.some((method) => method.id === currentShippingMethodId);
}

/**
 * Checks if the payment method type uses PayPal to render and complete payments
 */
export function isPayPalPaymentMethodType(paymentMethodType: string): boolean {
    return paymentMethodType === PAYMENT_METHOD_TYPES.PAYPAL || paymentMethodType === PAYMENT_METHOD_TYPES.VENMO;
}

/**
 * Finds the payment account/gateway for a given payment method type.
 */
export function findPaymentAccount(
    paymentMethods: PaymentMethod[] | undefined,
    paymentMethodSetAccounts: PaymentMethodSetAccount[] | undefined,
    paymentMethodType: string
): PaymentMethodSetAccount | null {
    if (!paymentMethodSetAccounts || !Array.isArray(paymentMethodSetAccounts)) {
        return null;
    }

    // Find payment method by type to get its accountId
    const paymentMethod = paymentMethods?.find((pm) => pm.paymentMethodType === paymentMethodType);
    if (!paymentMethod || !paymentMethod.accountId) {
        return null;
    }

    // Find account by accountId
    return paymentMethodSetAccounts.find((account) => account.accountId === paymentMethod.accountId) || null;
}

/**
 * Determines the gateway name from payment method type and payment method set accounts.
 */
export function getGatewayFromPaymentMethod(
    paymentMethodType: string,
    paymentMethods: PaymentMethod[] | undefined,
    paymentMethodSetAccounts: PaymentMethodSetAccount[] | undefined
): PaymentGateway | null {
    const account = findPaymentAccount(paymentMethods, paymentMethodSetAccounts, paymentMethodType);
    if (!account) {
        return null;
    }

    const vendor = account.vendor?.toLowerCase();
    if (vendor === PAYMENT_GATEWAYS.STRIPE) {
        return PAYMENT_GATEWAYS.STRIPE;
    } else if (vendor === PAYMENT_GATEWAYS.ADYEN) {
        return PAYMENT_GATEWAYS.ADYEN;
    } else if (vendor === PAYMENT_GATEWAYS.PAYPAL) {
        return PAYMENT_GATEWAYS.PAYPAL;
    }

    return null;
}
/**
 * PayPal sync payload for PATCH /baskets/.../payment-instruments/{piId}.
 * `amount` + `currencyCode` are required on every PATCH; `shippingOptions`
 * is sent only on address change. Requires the ECOM PATCH-PI validator
 * that consumes these fields — older ECOM versions drop them silently.
 */
export interface PayPalPatchSync {
    amount: string;
    currencyCode: string;
    shippingOptions?: Array<{
        id: string;
        label: string;
        amount: string;
        currencyCode: string;
        selected: boolean;
    }>;
}

/**
 * Creates a payment instrument body for Salesforce Payments (for basket or order).
 */
interface CreatePaymentInstrumentBodyParams {
    amount: number;
    paymentMethodType: PaymentMethodType;
    zoneId: string;
    shippingPreference?: string;
    paymentData?: Record<string, unknown>;
    storePaymentMethod?: boolean;
    futureUsageOffSession?: boolean;
    paymentMethods?: PaymentMethod[];
    paymentMethodSetAccounts?: PaymentMethodSetAccount[];
    isPostRequest?: boolean;
    paypalPatchSync?: PayPalPatchSync;
}

export function createPaymentInstrumentBody({
    amount,
    paymentMethodType,
    zoneId,
    shippingPreference,
    paymentData,
    storePaymentMethod = false,
    futureUsageOffSession = false,
    paymentMethods = [],
    paymentMethodSetAccounts = [],
    isPostRequest = false,
    paypalPatchSync,
}: CreatePaymentInstrumentBodyParams): ShopperBasketsV2.schemas['BasketPaymentInstrumentRequest'] {
    if (!zoneId) {
        throw new Error('Cannot build a payment instrument body without a zoneId');
    }
    const paymentReferenceRequest: Record<string, unknown> = {
        paymentMethodType,
        zoneId,
    };

    const gateway = getGatewayFromPaymentMethod(paymentMethodType, paymentMethods, paymentMethodSetAccounts);

    if (gateway === PAYMENT_GATEWAYS.PAYPAL && (shippingPreference != null || paypalPatchSync)) {
        paymentReferenceRequest.gateway = PAYMENT_GATEWAYS.PAYPAL;
        paymentReferenceRequest.gatewayProperties = {
            paypal: {
                ...(shippingPreference != null && { shippingPreference }),
                ...(paypalPatchSync && {
                    amount: paypalPatchSync.amount,
                    currencyCode: paypalPatchSync.currencyCode,
                    ...(paypalPatchSync.shippingOptions && { shippingOptions: paypalPatchSync.shippingOptions }),
                }),
            },
        };
    }

    if (!isPostRequest && gateway === PAYMENT_GATEWAYS.STRIPE) {
        const stripeGatewayProperties: Record<string, unknown> = {};

        if (storePaymentMethod || futureUsageOffSession) {
            stripeGatewayProperties.setupFutureUsage = futureUsageOffSession
                ? SETUP_FUTURE_USAGE.OFF_SESSION
                : SETUP_FUTURE_USAGE.ON_SESSION;
        }
        if (paymentData?.returnUrl) {
            stripeGatewayProperties.returnUrl = paymentData.returnUrl;
        }

        if (Object.keys(stripeGatewayProperties).length > 0) {
            paymentReferenceRequest.gateway = PAYMENT_GATEWAYS.STRIPE;
            paymentReferenceRequest.gatewayProperties = {
                stripe: stripeGatewayProperties,
            };
        }
    }

    if (!isPostRequest && gateway === PAYMENT_GATEWAYS.ADYEN) {
        paymentReferenceRequest.gateway = PAYMENT_GATEWAYS.ADYEN;
        paymentReferenceRequest.gatewayProperties = {
            adyen: {
                ...(paymentData && {
                    paymentMethod: paymentData.paymentMethod,
                    returnUrl: paymentData.returnUrl,
                    origin: paymentData.origin,
                    lineItems: paymentData.lineItems,
                    billingDetails: paymentData.billingDetails,
                    // ECOM derives Adyen `shopperName` by splitting `shippingDetails.name` —
                    // required for Afterpay/Clearpay; harmless for other methods.
                    shippingDetails: paymentData.shippingDetails,
                }),
                ...(storePaymentMethod && { storePaymentMethod: true }),
            },
        };
    }

    return {
        paymentMethodId: 'Salesforce Payments',
        amount,
        paymentReferenceRequest,
    };
}

/**
 * Build the PayPal PATCH sync payload from a basket + applicable shipping
 * methods. `amount` reflects the recomputed basket total; `shippingOptions`
 * is included only on address-change. On method-change pass `undefined` so
 * the wallet's shipping-options list isn't rewritten — only the selection
 * has changed, not the list.
 */
export function buildPaypalPatchSync(
    basket: ShopperBasketsV2.schemas['Basket'],
    applicableShippingMethods: Array<{ id?: string; name?: string; price?: number }> | undefined
): PayPalPatchSync | null {
    const total = basket.orderTotal ?? basket.productSubTotal;
    const currency = basket.currency;
    if (typeof total !== 'number' || !currency) return null;

    const selectedId = basket.shipments?.[0]?.shippingMethod?.id;
    const shippingOptions = applicableShippingMethods
        ?.filter(
            (m): m is { id: string; name: string; price: number } =>
                typeof m.id === 'string' && typeof m.name === 'string' && typeof m.price === 'number'
        )
        .map((m) => ({
            id: m.id,
            label: m.name,
            amount: m.price.toFixed(2),
            currencyCode: currency,
            selected: m.id === selectedId,
        }));

    return {
        amount: total.toFixed(2),
        currencyCode: currency,
        ...(shippingOptions && { shippingOptions }),
    };
}

/**
 * Maps express payment method type to underlying payment type.
 * For example, Apple Pay via Stripe uses 'card' as the payment method type.
 */
export function getExpressPaymentMethodType(
    type: string,
    paymentMethods: PaymentMethod[],
    paymentMethodSetAccounts: PaymentMethodSetAccount[]
): PaymentMethodType {
    const gateway = getGatewayFromPaymentMethod(type, paymentMethods, paymentMethodSetAccounts);

    // Stripe uses 'card' for Apple Pay / Google Pay
    if (
        gateway === PAYMENT_GATEWAYS.STRIPE &&
        (type === PAYMENT_METHOD_TYPES.APPLE_PAY || type === PAYMENT_METHOD_TYPES.GOOGLE_PAY)
    ) {
        return PAYMENT_METHOD_TYPES.CARD;
    }

    return type as PaymentMethodType;
}

/**
 * Build the redirect return URL for the payment-processing route.
 *
 * Shared by both express and payment sheet flows:
 *  - At SDK initialization — omit optional params to get the base URL.
 *  - Inside `createIntent` after order creation — pass all params to get the
 *    order-specific URL the gateway uses for redirect-based payment confirmation.
 */
export function buildPaymentProcessingUrl({
    origin,
    orderNo,
    zoneId,
    type,
    vendor,
}: {
    origin: string;
    orderNo?: string;
    zoneId?: string;
    type?: string;
    vendor?: string;
}): string {
    const params = new URLSearchParams();
    if (orderNo !== undefined) params.set('orderNo', orderNo);
    if (type !== undefined) params.set('type', type);
    if (zoneId !== undefined) params.set('zoneId', zoneId);
    if (vendor !== undefined) params.set('vendor', vendor);
    const qs = params.toString();
    return qs ? `${origin}/payment-processing?${qs}` : `${origin}/payment-processing`;
}

/**
 * Build the payload passed back to the SF Payments SDK from express shipping
 * callbacks (address change, method change).
 *
 * Pure function — computes the line-item breakdown, selected-method echo, and
 * total from a basket + applicable shipping methods. Throws if basket total is
 * missing or non-positive (the SDK rejects the callback otherwise).
 */
export function buildExpressCallbackData(
    basket: ShopperBasketsV2.schemas['Basket'],
    shippingMethodsResult: {
        applicableShippingMethods: Array<{ id: string; name: string; description?: string; price: number }>;
    },
    labels: ExpressCallbackLabels
): ExpressCallbackData {
    const selectedId = getSelectedShippingMethodId(basket);
    const methods = transformShippingMethods(
        shippingMethodsResult.applicableShippingMethods,
        basket,
        selectedId ?? null,
        true
    );
    const selected = methods.find((m) => m.id === selectedId) ?? methods[0];

    const total = basket.orderTotal ?? basket.productSubTotal;
    if (typeof total !== 'number' || !Number.isFinite(total) || total <= 0) {
        throw new Error('Invalid basket total amount');
    }

    // Subtotal line item is product subtotal so total === subtotal + shipping + tax.
    // Using `total` here would double-count shipping + tax against the top-line total
    // and cause wallets (Google Pay / Apple Pay) to reject the payload.
    const subtotal = basket.productSubTotal ?? total;
    const lineItems: Array<{ name: string; amount: string }> = [{ name: labels.subtotal, amount: subtotal.toString() }];
    if (basket.shippingTotal != null) {
        lineItems.push({ name: labels.shipping, amount: basket.shippingTotal.toString() });
    }
    if (basket.taxTotal != null) {
        lineItems.push({ name: labels.tax, amount: basket.taxTotal.toString() });
    }

    return { total: total.toString(), shippingMethods: methods, selectedShippingMethod: selected, lineItems };
}

/** Shape the SF Payments SDK expects for each entry in `savedPaymentMethods`. */
export interface SavedPaymentMethod {
    id: string;
    gatewayTokenId: string;
    gatewayId: string;
    type: string | null;
    name: string;
    status: string;
    isDefault: boolean;
    accountId: string | null;
    last4: string | null;
    network: string | null;
    usageType: string;
    accountHolderName: string | null;
    gatewayCustomerId: string;
    savedByMerchant: boolean;
}

/**
 * PayPal-specific shape on `paymentReference.gatewayProperties.paypal`,
 * populated by `GET /baskets/{id}?expand=paymentReference` when the basket
 * has a PayPal PI attached. Fields mirror PayPal's v2 order resource.
 */
export interface PayPalGatewayProperties {
    payer?: {
        givenName?: string;
        surname?: string;
        emailAddress?: string;
    };
    shipping?: {
        addressLine1?: string;
        addressLine2?: string;
        adminArea1?: string;
        adminArea2?: string;
        postalCode?: string;
        countryCode?: string;
    };
}

/**
 * Maps a PayPal gatewayProperties block to a basket-shaped address.
 * Returns null when shipping is unavailable (PayPal hasn't pushed the
 * shopper's address yet — the caller treats this as a transient miss).
 *
 * PayPal v2 order field names: adminArea1=stateCode, adminArea2=city,
 * givenName/surname=first/last name.
 */
export function transformPayPalAddressFromPaymentReference(
    paypal: PayPalGatewayProperties | undefined
): ShopperBasketsV2.schemas['OrderAddress'] | null {
    const shipping = paypal?.shipping;
    if (!shipping) return null;
    const payer = paypal?.payer ?? {};
    return {
        firstName: payer.givenName,
        lastName: payer.surname,
        address1: shipping.addressLine1,
        address2: shipping.addressLine2,
        city: shipping.adminArea2,
        stateCode: shipping.adminArea1,
        postalCode: shipping.postalCode,
        countryCode: shipping.countryCode,
    };
}

/**
 * Returns the `paymentReference` of the first PI on a basket/order whose
 * gateway matches. Used by the PayPal flow to read PayPal-specific gateway
 * properties (payer, shipping, purchase units) from the resolved basket.
 */
export function getPaymentReference(
    basketOrOrder: ShopperBasketsV2.schemas['Basket'] | ShopperOrders.schemas['Order'] | undefined,
    gateway: PaymentGateway = PAYMENT_GATEWAYS.PAYPAL
): { gateway?: string; gatewayProperties?: { paypal?: PayPalGatewayProperties } } | undefined {
    const pi = basketOrOrder?.paymentInstruments?.find(
        (p) => (p as { paymentReference?: { gateway?: string } })?.paymentReference?.gateway === gateway
    );
    return (
        pi as
            | { paymentReference?: { gateway?: string; gatewayProperties?: { paypal?: PayPalGatewayProperties } } }
            | undefined
    )?.paymentReference;
}

/**
 * Maps SCAPI `paymentMethodReferences` to the SDK's `savedPaymentMethods` shape.
 * Requires paymentMethodSetAccounts to resolve gatewayId; entries without a matching account are dropped.
 */
export function transformPaymentMethodReferences(
    refs: ShopperCustomers.schemas['CustomerPaymentMethodReference'][],
    paymentMethodSetAccounts: { accountId: string }[]
): SavedPaymentMethod[] {
    return refs.flatMap((ref) => {
        if (!ref.id || !ref.accountId) return [];
        const matchingAccount = paymentMethodSetAccounts.find((a) => a.accountId === ref.accountId);
        if (!matchingAccount) return [];
        const brand = (ref as { brand?: string }).brand;
        const name =
            ref.type === 'card'
                ? `${brand ?? 'Card'} **** ${ref.last4 ?? ''}`
                : ref.type === 'sepa_debit'
                  ? `Account ending in ${ref.last4 ?? ''}`
                  : 'Saved Payment Method';
        return [
            {
                id: ref.id,
                gatewayTokenId: ref.id,
                gatewayId: matchingAccount.accountId,
                type: ref.type ?? null,
                name,
                status: 'Active',
                isDefault: false,
                accountId: ref.accountId,
                last4: ref.last4 ?? null,
                network: brand ?? null,
                usageType: 'OffSession',
                accountHolderName: null,
                gatewayCustomerId: '',
                savedByMerchant: false,
            },
        ];
    });
}
