/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { Meta, StoryObj } from '@storybook/react-vite';
import PaymentMethods from '../index';

const meta = {
    title: 'SF Payments/Payment Methods',
    component: PaymentMethods,
    parameters: {
        layout: 'centered',
    },
    tags: ['autodocs'],
} satisfies Meta<typeof PaymentMethods>;

export default meta;
type Story = StoryObj<typeof meta>;

/**
 * Loading state - shown while SDK and payment config are initializing.
 */
export const Loading: Story = {
    decorators: [
        (Story) => (
            <div className="w-full max-w-2xl bg-card p-6 rounded-lg border">
                <Story />
            </div>
        ),
    ],
};

/**
 * Error state - shown when payment configuration fails to load.
 */
export const Error: Story = {
    decorators: [
        (Story) => (
            <div className="w-full max-w-2xl bg-card p-6 rounded-lg border">
                <Story />
            </div>
        ),
    ],
};

/**
 * Ready state - SDK loaded and ready to accept payment.
 * In a real environment, this would show the SF Payments SDK checkout UI.
 * In Storybook, we show a placeholder since the SDK requires a real backend.
 */
export const Ready: Story = {
    decorators: [
        (Story) => (
            <div className="w-full max-w-2xl bg-card p-6 rounded-lg border">
                <div className="mb-4 text-sm text-muted-foreground">
                    Note: In a real environment, the SF Payments SDK would render payment method UI here. This story
                    shows the component structure without the actual SDK integration.
                </div>
                <Story />
            </div>
        ),
    ],
};

/**
 * Registered shopper with saved payment methods — SDK receives the saved card list
 * and shows a picker alongside the save-for-future-use checkbox.
 */
export const RegisteredWithSavedMethods: Story = {
    decorators: [
        (Story) => (
            <div className="w-full max-w-2xl bg-card p-6 rounded-lg border">
                <div className="mb-4 text-sm text-muted-foreground">
                    Registered shopper with one saved card. The SDK receives the saved method and renders a card picker
                    with a save-for-future-use checkbox.
                </div>
                <Story />
            </div>
        ),
    ],
};

/**
 * No basket - component returns null when basket has no currency.
 */
export const NoBasket: Story = {
    decorators: [
        (Story) => (
            <div className="w-full max-w-2xl bg-card p-6 rounded-lg border">
                <div className="mb-4 text-sm text-muted-foreground">
                    When basket has no currency, component returns null (nothing rendered).
                </div>
                <Story />
            </div>
        ),
    ],
};
