/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import ExpressProcessingOverlay from './index';

vi.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (key: string) => key }),
}));

describe('ExpressProcessingOverlay', () => {
    it('renders nothing when isProcessing is false', () => {
        const { container } = render(<ExpressProcessingOverlay isProcessing={false} />);
        expect(container.firstChild).toBeNull();
    });

    it('renders an aria-live status region when isProcessing is true', () => {
        render(<ExpressProcessingOverlay isProcessing={true} />);
        const status = screen.getByRole('status');
        expect(status).toBeInTheDocument();
        expect(status).toHaveAttribute('aria-live', 'polite');
        expect(status).toHaveTextContent('expressProcessing.label');
    });
});
