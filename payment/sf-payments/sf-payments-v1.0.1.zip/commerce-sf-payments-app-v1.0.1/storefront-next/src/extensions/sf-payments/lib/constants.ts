/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

/**
 * Revalidation tag emitted by sf-payments action routes via `withRevalidateTags`.
 * Not in checkout's `CHECKOUT_REVALIDATE_TAGS` set, so the checkout route's
 * `shouldRevalidate` skips the loader re-run after our actions complete.
 * Host-contract value — keep in sync if checkout's revalidation policy changes.
 */
export const CHECKOUT_PAYMENT_COMPLETE_TAG = 'checkout.payment.complete';
