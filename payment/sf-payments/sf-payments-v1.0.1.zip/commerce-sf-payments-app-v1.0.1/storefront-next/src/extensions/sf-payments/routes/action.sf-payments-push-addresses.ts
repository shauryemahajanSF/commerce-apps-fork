/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError, type ShopperBasketsV2 } from '@/scapi';
import { getLogger } from '@/lib/logger.server';
import { withRevalidateTags } from '@/lib/revalidation/tags';
import { CHECKOUT_PAYMENT_COMPLETE_TAG } from '../lib/constants';
import {
    updateBillingAddressForBasket,
    updateCustomerForBasket,
    updateShippingAddressForShipment,
} from '../lib/api/basket-mutations.server';

type OrderAddress = ShopperBasketsV2.schemas['OrderAddress'];
const DEFAULT_SHIPMENT_ID = 'me';

/**
 * Push shipping and/or billing addresses onto a basket. At least one must
 * be provided. Called both after wallet approval (express — both) and from
 * the sheet flow's Place Order when the shopper picked a different billing
 * address (sheet — billing only).
 *
 * POST body (FormData — matches storefront-next's useFetcher convention;
 * complex values are JSON-stringified into individual fields):
 *   basketId: string (required)
 *   shippingAddress: JSON-stringified OrderAddress (optional)
 *   billingAddress: JSON-stringified OrderAddress (optional)
 *   email: string (optional — wallet-provided shopper email)
 *   shipmentId: string (optional, defaults to 'me')
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data({ success: false, error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);
    let basketId: string | undefined;
    try {
        const formData = await request.formData();
        basketId = formData.get('basketId')?.toString();
        const shippingAddressRaw = formData.get('shippingAddress')?.toString();
        const billingAddressRaw = formData.get('billingAddress')?.toString();
        const email = formData.get('email')?.toString();
        const shipmentId = formData.get('shipmentId')?.toString() || DEFAULT_SHIPMENT_ID;

        if (!basketId || (!shippingAddressRaw && !billingAddressRaw)) {
            return data(
                {
                    success: false,
                    error: 'basketId and at least one of shippingAddress or billingAddress are required',
                },
                { status: 400 }
            );
        }

        const shippingAddress = shippingAddressRaw ? (JSON.parse(shippingAddressRaw) as OrderAddress) : undefined;
        const billingAddress = billingAddressRaw ? (JSON.parse(billingAddressRaw) as OrderAddress) : undefined;

        let basket: ShopperBasketsV2.schemas['Basket'] | undefined;
        if (shippingAddress) {
            basket = await updateShippingAddressForShipment(context, basketId, shipmentId, shippingAddress);
        }
        if (billingAddress) {
            basket = await updateBillingAddressForBasket(context, basketId, billingAddress);
        }
        // Email update is best-effort: SCAPI can reject wallet-provided
        // emails (reserved-TLD sandboxes, malformed values). Skip on any
        // failure so the express flow still places the order.
        if (email) {
            try {
                basket = await updateCustomerForBasket(context, basketId, email);
            } catch (emailError: unknown) {
                logger.warn('[sf-payments] push-addresses: skipping wallet email update', {
                    ...(emailError instanceof ApiError ? emailError.toJSON() : { message: String(emailError) }),
                });
            }
        }
        return withRevalidateTags({ success: true, basket }, [CHECKOUT_PAYMENT_COMPLETE_TAG]);
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[sf-payments] push-addresses failed', {
            basketId,
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data(
            { success: false, error: isApiError ? error.body?.detail || error.message : String(error) },
            { status: isApiError ? error.status : 500 }
        );
    }
}
