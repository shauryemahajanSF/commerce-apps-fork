/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useCallback, useState } from 'react';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import { useBasket } from '@/providers/basket';
import { useTranslation } from 'react-i18next';
import { Card } from '@/components/ui/card';
import ExpressButtons from '../express-buttons';
import { EXPRESS_PAY_NOW } from '../../lib/sf-payments-utils';
import { getLocaleDerivedCountryCode } from '../../lib/sf-payments-country';

/**
 * Checkout-specific wrapper for ExpressButtons.
 *
 * Registered at the `sfcc.checkout.expressPayments` target. Uses the main basket
 * (no temporary basket creation) and renders express payment buttons with horizontal
 * layout. When payment methods are rendered, displays an "Express Checkout" heading
 * and separator.
 *
 * - Uses main cart only (no temp basket)
 * - Payment processing redirects to order confirmation page
 * - Supports Stripe and Adyen gateways
 */
export default function CheckoutExpressButtons() {
    const basket = useBasket();
    const { locale } = useSite();
    const { t } = useTranslation('checkout');
    const [showButtons, setShowButtons] = useState(false);

    const countryCode = basket?.billingAddress?.countryCode || getLocaleDerivedCountryCode(locale.id);
    const currency = basket?.currency;
    const initialAmount = basket?.orderTotal ?? basket?.productTotal;

    const prepareBasket = useCallback(() => {
        if (!basket) {
            return Promise.reject(new Error('No basket available'));
        }
        return Promise.resolve(basket);
    }, [basket]);

    const handlePaymentMethodsRendered = useCallback(() => {
        setShowButtons(true);
    }, []);

    if (!basket || !currency || !initialAmount) {
        return null;
    }

    const separatorText = t('expressPayments.separator', { defaultValue: 'or continue below' });

    return (
        <div className="space-y-6" data-testid="checkout-express-buttons-wrapper">
            <Card className="flex flex-col items-center gap-3 p-6 shadow-none">
                <p className="text-sm font-normal text-card-foreground">
                    {t('expressPayments.title', { defaultValue: 'Express Checkout' })}
                </p>
                <div className="w-full">
                    <ExpressButtons
                        prepareBasket={prepareBasket}
                        initialAmount={initialAmount}
                        currency={currency}
                        countryCode={countryCode}
                        usage={EXPRESS_PAY_NOW}
                        expressButtonLayout="horizontal"
                        maximumButtonCount={5}
                        onPaymentMethodsRendered={handlePaymentMethodsRendered}
                    />
                </div>
            </Card>

            {showButtons && (
                <div className="relative flex items-center gap-[15px]">
                    <div className="flex-1 h-px bg-separator" />
                    <span className="text-sm font-normal leading-5 text-muted-foreground whitespace-nowrap">
                        {separatorText}
                    </span>
                    <div className="flex-1 h-px bg-separator" />
                </div>
            )}
        </div>
    );
}
