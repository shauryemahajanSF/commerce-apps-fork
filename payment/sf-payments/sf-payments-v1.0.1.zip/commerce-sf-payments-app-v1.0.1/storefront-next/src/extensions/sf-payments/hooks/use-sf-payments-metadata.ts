/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

/**
 * Shape returned by the `/resource/sf-payments-metadata` resource route.
 *
 * Intentionally narrow: this is the SDK's rendering blueprint (payment method
 * types, gateway mappings, icon URLs). `sdkUrl` is NOT included — it's static
 * config read synchronously via `useConfig()` in the provider so the SDK
 * script can begin loading on first render without waiting for this fetch.
 */
export interface SFPaymentsMetadata {
    metadata: Record<string, unknown>;
}

// Module-level single-flight memo: concurrent callers share a single in-flight
// request rather than each firing their own fetch. This is request deduplication,
// not a data cache — there is no TTL or revalidation. The memo lives for the
// JS module lifetime (cleared on hard/soft refresh) and matches the pattern used
// by `fetchShopperConfig` and `fetchPaymentConfig`.
let pendingMetadataRequest: Promise<SFPaymentsMetadata> | null = null;

/**
 * Fetches SF Payments metadata (payment method types, gateway mappings, icons)
 * from the resource route.
 *
 * Imperative version for use by the lazy provider initialization. Concurrent
 * callers share a single in-flight request via module-level memoization. On
 * failure the memo is cleared so the next consumer can retry.
 */
export function fetchMetadata(): Promise<SFPaymentsMetadata> {
    if (pendingMetadataRequest) return pendingMetadataRequest;

    pendingMetadataRequest = fetch('/resource/sf-payments-metadata')
        .then(async (res) => {
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            return res.json();
        })
        .then(
            (data): SFPaymentsMetadata => ({
                metadata: data.metadata ?? data,
            })
        )
        .catch((err) => {
            pendingMetadataRequest = null;
            throw err;
        });

    return pendingMetadataRequest;
}
