/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import type { LoaderFunctionArgs } from 'react-router';
import { createApiClients } from '@/lib/api-clients.server';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';

/**
 * Returns raw SCAPI paymentMethodReferences for a registered shopper.
 * Guests get an empty array. The client transforms the refs into the SDK shape
 * once paymentConfig (needed for gatewayId resolution) is available.
 *
 * GET /resource/sf-payments-saved-methods
 */
export async function loader({ context }: LoaderFunctionArgs) {
    try {
        const { customerId, userType } = getAuth(context);

        if (userType !== 'registered' || !customerId) {
            return Response.json([]);
        }

        const clients = createApiClients(context);
        const { data: customer } = await clients.shopperCustomers.getCustomer({
            params: { path: { customerId }, query: { expand: ['paymentmethodreferences'] } },
        });

        return Response.json(customer.paymentMethodReferences ?? []);
    } catch (error) {
        getLogger(context).error('[sf-payments] fetch saved payment methods failed', {
            message: error instanceof Error ? error.message : String(error),
        });
        return Response.json([]);
    }
}
