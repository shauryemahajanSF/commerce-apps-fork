/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { describe, test, expect, vi, beforeEach } from 'vitest';

// React 19 production builds don't expose `act`, which makes
// @testing-library/react's renderHook crash. Stub the React hooks the
// strategy uses (useCallback) so we can call it as a regular function.
vi.mock('react', () => ({
    useCallback: <T,>(fn: T) => fn,
}));

import { usePaypalStrategy } from './use-paypal-strategy';
import type { PaymentConfig } from '../../lib/api/types';

const submitSpies = {
    ensure: vi.fn(),
    resolve: vi.fn(),
    create: vi.fn(),
};

const promiseResolvers = {
    ensure: vi.fn(),
    resolve: vi.fn(),
    create: vi.fn(),
};

vi.mock('react-router', () => ({
    useFetcher: vi.fn(),
}));

vi.mock('../use-fetcher-promise', () => ({
    useFetcherPromise: vi.fn(),
}));

import { useFetcher } from 'react-router';
import { useFetcherPromise } from '../use-fetcher-promise';

const paymentConfig: PaymentConfig = {
    zoneId: 'z1',
    paymentMethods: [{ paymentMethodType: 'paypal', accountId: 'acct_paypal' }],
    paymentMethodSetAccounts: [{ accountId: 'acct_paypal', vendor: 'PayPal' }],
};

const baseBasket = {
    basketId: 'b1',
    paymentInstruments: [
        {
            paymentMethodId: 'Salesforce Payments',
            paymentInstrumentId: 'opi-1',
            paymentReference: { paymentReferenceId: 'pref-1' },
        },
    ],
};

const baseOrder = {
    orderNo: 'o-1',
    paymentInstruments: [
        {
            paymentMethodId: 'Salesforce Payments',
            paymentInstrumentId: 'opi-1',
            paymentReference: { paymentReferenceId: 'pref-1' },
        },
    ],
};

beforeEach(() => {
    submitSpies.ensure.mockReset();
    submitSpies.resolve.mockReset();
    submitSpies.create.mockReset();
    promiseResolvers.ensure.mockReset();
    promiseResolvers.resolve.mockReset();
    promiseResolvers.create.mockReset();

    // Strategy creates fetchers in declaration order: ensure, resolve, create.
    const fetchers = [
        { submit: submitSpies.ensure, state: 'idle', data: undefined },
        { submit: submitSpies.resolve, state: 'idle', data: undefined },
        { submit: submitSpies.create, state: 'idle', data: undefined },
    ];
    let fetcherIdx = 0;
    vi.mocked(useFetcher).mockImplementation(() => fetchers[fetcherIdx++] as unknown as ReturnType<typeof useFetcher>);

    const resolvers = [promiseResolvers.ensure, promiseResolvers.resolve, promiseResolvers.create];
    let resolverIdx = 0;
    vi.mocked(useFetcherPromise).mockImplementation(
        () => resolvers[resolverIdx++] as unknown as ReturnType<typeof useFetcherPromise>
    );
});

describe('usePaypalStrategy', () => {
    test('returned shape: prepareBasketOnClick=false, has createIntent + onPayerApprove + onApprove', () => {
        const result = { current: usePaypalStrategy() };

        expect(result.current.prepareBasketOnClick).toBe(false);
        expect(result.current).toHaveProperty('createIntent', expect.any(Function));
        expect(result.current).toHaveProperty('onPayerApprove', expect.any(Function));
        expect(result.current).toHaveProperty('onApprove', expect.any(Function));
    });

    test('createIntent: ensures PI and returns { id } from the basket PI paymentReferenceId', async () => {
        promiseResolvers.ensure.mockResolvedValue({ success: true, basket: baseBasket });

        const result = { current: usePaypalStrategy() };
        const intent = await result.current.createIntent({
            basket: baseBasket,
            paymentMethodType: 'paypal',
            paymentConfig,
            baseUrl: 'https://example.com',
        });

        expect(submitSpies.ensure).toHaveBeenCalledWith(
            expect.any(FormData),
            expect.objectContaining({ method: 'POST', action: '/action/sf-payments-ensure-pi' })
        );
        const ensureForm = submitSpies.ensure.mock.calls[0][0] as FormData;
        expect(ensureForm.get('paymentMethodType')).toBe('paypal');

        // PayPal does NOT create the order in createIntent.
        expect(submitSpies.create).not.toHaveBeenCalled();
        expect(intent).toEqual({ sdkResult: { id: 'pref-1' } });
    });

    test('createIntent throws when ensure-pi returns success: false', async () => {
        promiseResolvers.ensure.mockResolvedValue({ success: false, error: 'pi failed' });

        const result = { current: usePaypalStrategy() };
        await expect(
            result.current.createIntent({
                basket: baseBasket,
                paymentMethodType: 'paypal',
                paymentConfig,
                baseUrl: 'https://example.com',
            })
        ).rejects.toThrow('pi failed');
    });

    test('createIntent throws when basket is missing a paymentReferenceId after ensure', async () => {
        const basketWithoutRef = {
            basketId: 'b1',
            paymentInstruments: [
                {
                    paymentMethodId: 'Salesforce Payments',
                    paymentInstrumentId: 'opi-1',
                    paymentReference: {},
                },
            ],
        };
        promiseResolvers.ensure.mockResolvedValue({ success: true, basket: basketWithoutRef });

        const result = { current: usePaypalStrategy() };
        await expect(
            result.current.createIntent({
                basket: baseBasket,
                paymentMethodType: 'paypal',
                paymentConfig,
                baseUrl: 'https://example.com',
            })
        ).rejects.toThrow(/paymentReferenceId/);
    });

    test('onPayerApprove: posts basketId to resolve-paypal-addresses and returns the resolved basket', async () => {
        promiseResolvers.resolve.mockResolvedValue({ success: true, basket: baseBasket });

        const result = { current: usePaypalStrategy() };
        if (!result.current.onPayerApprove) throw new Error('PayPal strategy is missing onPayerApprove');
        const onProcessingStarted = vi.fn();
        const updated = await result.current.onPayerApprove({
            basket: baseBasket,
            paymentMethodType: 'paypal',
            paymentConfig,
            onProcessingStarted,
        });

        expect(onProcessingStarted).toHaveBeenCalled();
        expect(submitSpies.resolve).toHaveBeenCalledWith(
            expect.any(FormData),
            expect.objectContaining({ method: 'POST', action: '/action/sf-payments-resolve-paypal-addresses' })
        );
        const resolveForm = submitSpies.resolve.mock.calls[0][0] as FormData;
        expect(resolveForm.get('basketId')).toBe('b1');
        expect(updated).toBe(baseBasket);
    });

    test('onPayerApprove throws paypal_address_unavailable when resolve fails', async () => {
        promiseResolvers.resolve.mockResolvedValue({ success: false, error: 'paypal_address_unavailable' });

        const result = { current: usePaypalStrategy() };
        if (!result.current.onPayerApprove) throw new Error('PayPal strategy is missing onPayerApprove');
        await expect(
            result.current.onPayerApprove({
                basket: baseBasket,
                paymentMethodType: 'paypal',
                paymentConfig,
            })
        ).rejects.toThrow('paypal_address_unavailable');
    });

    test('onApprove: creates the commerce order and returns order + paymentReferenceId', async () => {
        promiseResolvers.create.mockResolvedValue({ success: true, order: baseOrder, orderNo: 'o-1' });

        const result = { current: usePaypalStrategy() };
        if (!result.current.onApprove) throw new Error('PayPal strategy is missing onApprove');
        const out = await result.current.onApprove({
            basket: baseBasket,
            paymentMethodType: 'paypal',
            paymentConfig,
            baseUrl: 'https://example.com',
        });

        expect(submitSpies.create).toHaveBeenCalledWith(
            expect.any(FormData),
            expect.objectContaining({ method: 'POST', action: '/action/sf-payments-create-order' })
        );
        const createForm = submitSpies.create.mock.calls[0][0] as FormData;
        expect(createForm.get('basketId')).toBe('b1');
        expect(createForm.get('paymentMethodType')).toBe('paypal');
        expect(createForm.get('origin')).toBe('https://example.com');

        expect(out).toEqual({ order: baseOrder, orderNo: 'o-1', paymentReferenceId: 'pref-1' });
    });

    test('onApprove with skipPostOrderRevalidation: posts via plain fetch, skips createOrder fetcher', async () => {
        const fetchSpy = vi.spyOn(global, 'fetch').mockResolvedValue({
            ok: true,
            json: () => Promise.resolve({ success: true, order: baseOrder, orderNo: 'o-1' }),
        } as Response);

        try {
            const result = { current: usePaypalStrategy() };
            if (!result.current.onApprove) throw new Error('PayPal strategy is missing onApprove');
            await result.current.onApprove({
                basket: baseBasket,
                paymentMethodType: 'paypal',
                paymentConfig,
                baseUrl: 'https://example.com',
                skipPostOrderRevalidation: true,
            });

            expect(fetchSpy).toHaveBeenCalledWith(
                '/action/sf-payments-create-order',
                expect.objectContaining({ method: 'POST', body: expect.any(FormData) })
            );
            expect(submitSpies.create).not.toHaveBeenCalled();
        } finally {
            fetchSpy.mockRestore();
        }
    });

    test('onApprove throws when the order is missing a paymentReferenceId', async () => {
        const orderWithoutRef = {
            orderNo: 'o-1',
            paymentInstruments: [
                {
                    paymentMethodId: 'Salesforce Payments',
                    paymentInstrumentId: 'opi-1',
                    paymentReference: {},
                },
            ],
        };
        promiseResolvers.create.mockResolvedValue({ success: true, order: orderWithoutRef });

        const result = { current: usePaypalStrategy() };
        if (!result.current.onApprove) throw new Error('PayPal strategy is missing onApprove');
        await expect(
            result.current.onApprove({
                basket: baseBasket,
                paymentMethodType: 'paypal',
                paymentConfig,
                baseUrl: 'https://example.com',
            })
        ).rejects.toThrow(/paymentReferenceId/);
    });
});
