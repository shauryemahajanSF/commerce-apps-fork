/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useCallback } from 'react';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import { useBasket } from '@/providers/basket';
import ExpressButtons from '../express-buttons';
import { EXPRESS_PAY_NOW } from '../../lib/sf-payments-utils';
import { getLocaleDerivedCountryCode } from '../../lib/sf-payments-country';

/**
 * Mini-cart-specific wrapper for ExpressButtons.
 *
 * Registered at the `sfcc.miniCart.payments.expressCheckout` target. Uses the main basket
 * (no temporary basket creation) and renders express payment buttons with vertical layout
 * optimized for drawer/overlay UI. Maximum 3 buttons to fit constrained drawer width.
 *
 * - Uses main cart only (no temp basket)
 * - Payment processing redirects to order confirmation page
 * - Supports Stripe and Adyen gateways
 * - Vertical layout (2-3 buttons max) for drawer UI
 */
export default function MiniCartExpressButtons() {
    const basket = useBasket();
    const { locale } = useSite();

    const countryCode = basket?.billingAddress?.countryCode || getLocaleDerivedCountryCode(locale.id);
    const currency = basket?.currency;
    const initialAmount = basket?.orderTotal ?? basket?.productTotal;

    const prepareBasket = useCallback(() => {
        if (!basket) {
            return Promise.reject(new Error('No basket available'));
        }
        return Promise.resolve(basket);
    }, [basket]);

    if (!basket || !currency || !initialAmount) {
        return null;
    }

    return (
        <div className="w-full" data-testid="mini-cart-express-buttons-wrapper">
            <ExpressButtons
                prepareBasket={prepareBasket}
                initialAmount={initialAmount}
                currency={currency}
                countryCode={countryCode}
                usage={EXPRESS_PAY_NOW}
                expressButtonLayout="vertical"
                maximumButtonCount={4}
            />
        </div>
    );
}
