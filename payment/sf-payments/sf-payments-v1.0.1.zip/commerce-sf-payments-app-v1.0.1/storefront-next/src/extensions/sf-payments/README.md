# SF Payments — Extension Internals

This README ships inside the storefront-next extension at
`src/extensions/sf-payments/`. It documents the internal structure for
developers extending or debugging the extension.

For merchant install/configuration docs, see the root `README.md` of the
CAP (one directory up in the unzipped package).

## Layout

```
components/     UI components registered at host UITargets
  cart-express-buttons/
  mini-cart-express-buttons/
  pdp-express-buttons/
  checkout-express-buttons/
  express-buttons/         shared express-flow shell
  payment-methods/         checkout payment sheet
providers/                 SF Payments React provider (SDK lifecycle)
hooks/
  gateways/                per-gateway strategies (Stripe, Adyen, PayPal)
  use-sf-payments-config.ts
  use-sf-payments-metadata.ts
lib/api/                   gateway- and flow-agnostic basket/order mutations
routes/                    React Router resource routes (SCAPI proxies)
locales/                   en-US / en-GB / it-IT translations
target-config.json         component → UITarget registration
index.ts                   public exports
```

## Architecture Layering

Payment flows are split across four layers so that **flow** (express vs.
payment-sheet) and **gateway** (Stripe vs. Adyen vs. PayPal) vary
independently:

1. **Components** — flow-aware, gateway-agnostic.
2. **Callback hooks** — flow-aware, gateway-agnostic. Delegate SDK
   callbacks to the gateway strategy.
3. **Gateway strategies** (`hooks/gateways/*`) — gateway-aware,
   flow-agnostic. Produce the SDK-shaped payload each vendor expects.
4. **Mutations / action routes** (`lib/api/*`) — gateway-agnostic,
   flow-agnostic. Take a basket and config, never a flow or gateway.

If a mutation grows an `if (gateway === 'stripe')` branch, the
abstraction has leaked into the wrong layer — push it back into a
strategy.

## Errors

The payment sheet does not paint its own Place Order error UI. Errors
bubble to a host channel so the checkout team's Place Order surface
owns the messaging. Don't add inline error banners inside sheet
components for Place Order failures.

## Further Reading

Full HLD/LLD/spec docs live in `docs/sf-payments/` in the source repo
(not shipped in the CAP).
