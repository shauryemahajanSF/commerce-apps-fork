/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import type { ShopperBasketsV2, ShopperOrders } from '@/scapi';
import { createLogger } from '@/lib/logger';
import { useSelectGatewayStrategy } from '../../hooks/gateways/use-select-gateway-strategy';
import { useSFPaymentsFailureRecovery } from '../../hooks/use-sf-payments-failure-recovery';
import type { PaymentConfig } from '../../lib/api/types';
import type { SdkIntentPayload } from '../../lib/gateways/types';
import { findPaymentAccount, SDK_RESPONSE_CODE, type PaymentMethodType } from '../../lib/sf-payments-utils';

/**
 * Gateway-specific payload forwarded from the SF Payments SDK to createIntent.
 *
 * - Stripe: SDK calls createIntent() with no arguments — this will be undefined.
 * - Adyen: SDK passes encrypted card data (paymentMethod), origin, returnUrl,
 *   browserInfo, billingDetails, shippingDetails.
 *
 * Intentionally opaque (Record<string, unknown>) because the SDK is the source
 * of truth for each gateway's shape, and new gateways can be added without
 * touching this type. Gateway-specific narrowing happens inside each strategy.
 */
type SdkPaymentData = Record<string, unknown>;

/**
 * Callback that appends query params to the SDK config's returnUrl.
 * The component owns the config mutation; the hook only declares what params it needs.
 */
export type UpdateReturnUrlParams = (params: Record<string, string>) => void;

export interface SFPCheckoutComponent {
    confirm: (
        data: null,
        billingDetails: Record<string, unknown>,
        shippingDetails: Record<string, unknown>
    ) => Promise<{ responseCode: number; data?: unknown }>;
    updateAmount: (amount: number) => void;
    destroy: () => void;
    selectedPaymentMethod?: { paymentMethodType: PaymentMethodType };
}

type Basket = ShopperBasketsV2.schemas['Basket'];
type OrderAddress = ShopperBasketsV2.schemas['OrderAddress'];
type Order = ShopperOrders.schemas['Order'];

const logger = createLogger();

/**
 * Extract the human-readable vendor message from an SDK error/result payload.
 *
 * SDK shape varies: thrown payloads nest a full PaymentIntent + PaymentMethod
 * under `data.error.message`; resolved failure results collapse to a bare
 * string on `data.error`. Handle both. The full nested payload never belongs
 * in browser logs — vendor-specific codes live in the vendor's dashboard,
 * searchable by basketId/orderNo.
 */
function extractVendorMessage(payload: unknown): string | undefined {
    const error = (payload as { error?: unknown } | null)?.error;
    if (typeof error === 'string') return error;
    const msg = (error as { message?: unknown } | null)?.message;
    return typeof msg === 'string' ? msg : undefined;
}

/**
 * Reads the shopper's current billing address from the host checkout form.
 * Returns null when "use different billing" is not checked. The host persists
 * this value to `basket.billingAddress` before invoking `onPlaceOrder`, so we
 * only need the read-path to shape the SDK's `billingDetails` payload.
 */
export type BillingAddressGetter = () => OrderAddress | null;

interface UsePaymentMethodsCallbacksOptions {
    /** Current basket from checkout */
    basket: Basket | null | undefined;
    /** Resolved payment configuration */
    paymentConfig: PaymentConfig | null | undefined;
    /** Ref to the SDK checkout component instance */
    checkoutComponentRef: React.MutableRefObject<SFPCheckoutComponent | null>;
    /** Ref to the currently selected payment method type */
    paymentMethodTypeRef: React.MutableRefObject<PaymentMethodType | ''>;
    /**
     * Whether the shopper opted in to saving the payment method. A ref so
     * createIntent stays stable when the checkbox toggles — no callback re-creation.
     */
    storePaymentMethodRef: React.MutableRefObject<boolean>;
    /** Whether the gateway should store the payment method for off-session use. Must match the SDK's futureUsageOffSession option. */
    futureUsageOffSession: boolean;
    /** Resolved site prefix (e.g. "/RefArch/en-US") for building the return URL. */
    sitePrefix: string;
    /** Appends query params to the SDK config's returnUrl without exposing the config. */
    updateReturnUrl: UpdateReturnUrlParams;
    /**
     * Reads the shopper-entered billing address from the host at Place Order
     * time. When it returns non-null, we shape the SDK's `billingDetails`
     * payload from this instead of `basket.billingAddress` — the host persists
     * the same value before calling `onPlaceOrder`, but the basket in our
     * closure is stale until React re-renders. Optional; flows without a host
     * form omit it and we read billing off the basket as before.
     */
    getBillingAddress?: BillingAddressGetter;
}

export interface ConfirmPaymentResult {
    success: boolean;
    orderNo?: string;
    error?: string;
    basketRecovered?: boolean;
}

interface PaymentMethodsCallbacksResult {
    createIntent: (paymentData?: SdkPaymentData) => Promise<SdkIntentPayload>;
    confirmPayment: () => Promise<ConfirmPaymentResult>;
    /**
     * Event handler for `sfp:paymentapprove`. When the active strategy defines
     * `onApprove`, it finalizes the commerce order and resolves with the
     * orderNo for the caller to navigate. Strategies without `onApprove`
     * short-circuit and rely on the existing Place Order path.
     */
    onPaymentApprove: () => Promise<{ orderNo?: string; error?: string }>;
}

/**
 * Payment methods callbacks hook for the checkout sheet flow.
 *
 * Provides createIntent and confirmPayment callbacks for the SF Payments SDK.
 * Unlike express callbacks, this hook:
 * - Uses the main basket (no temp basket creation)
 * - No address callbacks (billing/shipping already set via checkout forms)
 * - Manual confirm required (not automatic)
 *
 * Follows the 4-layer architecture: Component → Callbacks → Gateway Strategy → Action Routes.
 * This hook delegates to the shared gateway strategies rather than calling action routes directly.
 */
export function usePaymentMethodsCallbacks({
    basket,
    paymentConfig,
    checkoutComponentRef,
    paymentMethodTypeRef,
    storePaymentMethodRef,
    futureUsageOffSession,
    sitePrefix,
    updateReturnUrl,
    getBillingAddress,
}: UsePaymentMethodsCallbacksOptions): PaymentMethodsCallbacksResult {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { t } = useTranslation('extSfPayments' as any);
    const selectStrategy = useSelectGatewayStrategy();
    const { failAndRecover } = useSFPaymentsFailureRecovery();

    const orderRef = useRef<Order | null>(null);
    const failOrderCalledRef = useRef(false);

    /**
     * createIntent callback — called by SDK when shopper submits payment.
     * Delegates to the shared gateway strategy and forwards its SDK-shaped
     * payload to the SDK; captures the order (when present) for navigation.
     */
    const createIntent = useCallback(
        async (paymentData?: SdkPaymentData): Promise<SdkIntentPayload> => {
            if (!paymentConfig) {
                throw new Error('Payment configuration is not resolved');
            }
            if (!basket || !basket.basketId) {
                throw new Error('Basket is not available');
            }

            const selectedMethod = checkoutComponentRef.current?.selectedPaymentMethod;
            let paymentMethodType: PaymentMethodType;
            if (selectedMethod?.paymentMethodType) {
                paymentMethodType = selectedMethod.paymentMethodType;
            } else if (paymentMethodTypeRef.current) {
                paymentMethodType = paymentMethodTypeRef.current;
            } else {
                throw new Error('No payment method type selected');
            }

            const strategy = selectStrategy(paymentMethodType, paymentConfig);

            const { sdkResult, order } = await strategy.createIntent({
                basket,
                paymentMethodType,
                paymentConfig,
                baseUrl: window.location.origin + sitePrefix,
                paymentData,
                storePaymentMethod: storePaymentMethodRef.current,
                futureUsageOffSession,
                // Sheet flow: address is already on the basket from the
                // checkout form. Tell PayPal to use that address and not
                // invite the shopper to change it in the popup.
                shippingPreference: 'SET_PROVIDED_ADDRESS',
            });

            if (order) {
                orderRef.current = order;
            }

            if (order?.orderNo) {
                const params: Record<string, string> = { orderNo: order.orderNo };
                const account = findPaymentAccount(
                    paymentConfig.paymentMethods,
                    paymentConfig.paymentMethodSetAccounts,
                    paymentMethodType
                );
                if (account?.vendor) {
                    params.vendor = account.vendor;
                }
                updateReturnUrl(params);
            }

            return sdkResult;
        },
        [
            basket,
            paymentConfig,
            checkoutComponentRef,
            paymentMethodTypeRef,
            storePaymentMethodRef,
            futureUsageOffSession,
            sitePrefix,
            updateReturnUrl,
            selectStrategy,
        ]
    );

    /**
     * confirmPayment - manually called when place order button is clicked.
     * Calls SDK confirm method and returns result for navigation.
     */
    const confirmPayment = useCallback(async (): Promise<ConfirmPaymentResult> => {
        failOrderCalledRef.current = false;

        if (!checkoutComponentRef.current) {
            return { success: false, error: t('paymentMethods.errorInitializing') };
        }

        if (!basket || !basket.basketId) {
            return { success: false, error: t('paymentMethods.errorBasketUnavailable') };
        }

        // Host persists a shopper-chosen billing address (from
        // PaymentSubmissionRef.billingAddressGetter) before invoking
        // onPlaceOrder. Prefer that fresh value when present — the basket in
        // our closure hasn't re-fetched yet.
        const billingOverride = getBillingAddress?.() ?? null;
        const billingSource = billingOverride ?? basket.billingAddress;

        const billingDetails: Record<string, unknown> = {};
        if (basket.customerInfo?.email) {
            billingDetails.email = basket.customerInfo.email;
        }
        if (billingSource) {
            const derivedName = [billingSource.firstName, billingSource.lastName].filter(Boolean).join(' ');
            billingDetails.phone = billingSource.phone;
            // Fall back to fullName when first/last are absent — saved or
            // imported addresses may only carry the combined field.
            billingDetails.name = derivedName || billingSource.fullName || undefined;
            billingDetails.address = {
                line1: billingSource.address1,
                line2: billingSource.address2,
                city: billingSource.city,
                state: billingSource.stateCode,
                postalCode: billingSource.postalCode,
                country: billingSource.countryCode,
            };
        }

        const shippingDetails: Record<string, unknown> = {};
        if (basket.shipments?.[0]?.shippingAddress) {
            const addr = basket.shipments[0].shippingAddress;
            shippingDetails.name = addr.fullName;
            shippingDetails.address = {
                line1: addr.address1,
                line2: addr.address2,
                city: addr.city,
                state: addr.stateCode,
                postalCode: addr.postalCode,
                country: addr.countryCode,
            };
        }

        try {
            const result = await checkoutComponentRef.current.confirm(null, billingDetails, shippingDetails);

            // SDK type says non-null, but we've seen null slip through on
            // intermittent failures — log the state and treat as non-success.
            if (!result || result.responseCode !== SDK_RESPONSE_CODE.SUCCESS) {
                const vendorMessage = extractVendorMessage(result?.data);
                const shopperMessage = vendorMessage ?? t('paymentMethods.errorConfirmationFailed');
                logger.error('[sf-payments] SDK confirm() returned non-success', {
                    paymentMethodType: paymentMethodTypeRef.current,
                    basketId: basket.basketId,
                    orderNo: orderRef.current?.orderNo,
                    responseCode: result?.responseCode ?? null,
                    vendorMessage,
                });
                if (failOrderCalledRef.current) {
                    return { success: false, error: shopperMessage };
                }
                failOrderCalledRef.current = true;
                const recovery = await failAndRecover(orderRef.current?.orderNo ?? '', 'sheet');
                return {
                    success: false,
                    error: shopperMessage,
                    basketRecovered: recovery.basketRecovered,
                };
            }

            const orderNo = orderRef.current?.orderNo;
            if (!orderNo) {
                return { success: false, error: t('paymentMethods.errorOrderMissing') };
            }

            orderRef.current = null;
            return { success: true, orderNo };
        } catch (error) {
            // SDK throws a result-shaped payload on card decline (and similar
            // vendor rejections) — surface that message to the shopper. For
            // anything else (JS TypeError, network failure, etc.) show a
            // generic message; the raw error.message stays in the log for triage.
            const vendorMessage = extractVendorMessage((error as { data?: unknown } | null)?.data);
            const shopperMessage = vendorMessage ?? t('paymentMethods.errorConfirmationFailed');
            logger.error('[sf-payments] confirmPayment threw', {
                paymentMethodType: paymentMethodTypeRef.current,
                basketId: basket.basketId,
                orderNo: orderRef.current?.orderNo,
                errorName: error instanceof Error ? error.name : undefined,
                errorMessage: error instanceof Error ? error.message : undefined,
                vendorMessage,
            });
            if (failOrderCalledRef.current) {
                return { success: false, error: shopperMessage };
            }
            failOrderCalledRef.current = true;
            const recovery = await failAndRecover(orderRef.current?.orderNo ?? '', 'sheet');
            return {
                success: false,
                error: shopperMessage,
                basketRecovered: recovery.basketRecovered,
            };
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps -- basket is read off the closure but `confirmPayment` is invoked synchronously from Place Order; rebinding on every basket update would defeat the stable-callback design
    }, [checkoutComponentRef, failAndRecover, getBillingAddress, t]);

    /**
     * Sheet `sfp:paymentapprove` handler. When the active strategy defines
     * `onApprove`, it owns the post-approval order creation and we surface
     * the resulting orderNo. Otherwise this no-ops and the existing Place
     * Order path stays in charge of finalization.
     */
    const onPaymentApprove = useCallback(async (): Promise<{ orderNo?: string; error?: string }> => {
        // Re-entry guard: SDK can fire `sfp:paymentapprove` twice on rare
        // network/double-tap edge cases. If we already have an order, surface
        // the existing orderNo instead of creating a duplicate.
        if (orderRef.current?.orderNo) {
            return { orderNo: orderRef.current.orderNo };
        }
        if (!paymentConfig || !basket?.basketId) {
            return { error: t('paymentMethods.errorBasketUnavailable') };
        }
        const paymentMethodType =
            checkoutComponentRef.current?.selectedPaymentMethod?.paymentMethodType || paymentMethodTypeRef.current;
        if (!paymentMethodType) {
            // Should never happen — the SDK only fires sfp:paymentapprove after
            // a method was selected. Treat as a confirmation/approval failure.
            return { error: t('paymentMethods.errorConfirmationFailed') };
        }
        const strategy = selectStrategy(paymentMethodType, paymentConfig);
        if (!strategy.onApprove) {
            // Strategy doesn't define onApprove — caller handles finalization.
            return {};
        }
        try {
            const result = await strategy.onApprove({
                basket,
                paymentMethodType,
                paymentConfig,
                baseUrl: window.location.origin + sitePrefix,
            });
            const order = (result as { order?: Order })?.order;
            if (order) orderRef.current = order;
            const orderNo = order?.orderNo ?? (result as { orderNo?: string })?.orderNo;
            if (!orderNo) return { error: t('paymentMethods.errorOrderMissing') };
            return { orderNo };
        } catch (error) {
            const vendorMessage = extractVendorMessage((error as { data?: unknown } | null)?.data);
            logger.error('[sf-payments] onPaymentApprove strategy failed', {
                paymentMethodType,
                basketId: basket.basketId,
                orderNo: orderRef.current?.orderNo,
                errorName: error instanceof Error ? error.name : undefined,
                errorMessage: error instanceof Error ? error.message : String(error),
                vendorMessage,
            });
            return { error: vendorMessage ?? t('paymentMethods.errorConfirmationFailed') };
        }
    }, [basket, paymentConfig, paymentMethodTypeRef, checkoutComponentRef, selectStrategy, sitePrefix, t]);

    return {
        createIntent,
        confirmPayment,
        onPaymentApprove,
    };
}
