/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { beforeEach, describe, expect, test, vi } from 'vitest';
import type { RouterContextProvider } from 'react-router';
import { action } from './action.sf-payments-update-shipping-address';
import {
    getShippingMethodsForShipment,
    patchPaymentInstrumentOnBasket,
    updateShippingAddressForShipment,
    validateAndUpdateShippingMethod,
} from '../lib/api/basket-mutations.server';

vi.mock('../lib/api/basket-mutations.server', () => ({
    getShippingMethodsForShipment: vi.fn(),
    patchPaymentInstrumentOnBasket: vi.fn(),
    updateShippingAddressForShipment: vi.fn(),
    validateAndUpdateShippingMethod: vi.fn(),
}));

vi.mock('@/lib/logger.server', () => ({
    getLogger: vi.fn(() => ({ error: vi.fn(), info: vi.fn() })),
}));

const mockContext = { get: vi.fn(), set: vi.fn() } as unknown as RouterContextProvider;

// react-router's data() returns { type, data, init } — not a native Response.
function dataOf(result: unknown): { success: boolean; error?: string; basket?: unknown } {
    const d = (result as { data?: unknown })?.data;
    return (d ?? result) as { success: boolean; error?: string; basket?: unknown };
}

const ADDRESS = { firstName: 'Jane', city: 'SF' };
const LABELS = { subtotal: 'Subtotal', shipping: 'Shipping', tax: 'Tax' };
const METHODS = {
    applicableShippingMethods: [{ id: 'std', name: 'Standard', description: 'Ground', price: 5 }],
    defaultShippingMethodId: 'std',
};
const BASKET_AFTER = {
    basketId: 'b1',
    currency: 'USD',
    orderTotal: 100,
    productSubTotal: 90,
    shipments: [{ shippingMethod: { id: 'std' } }],
};
const PAYMENT_CONFIG = { zoneId: 'z1', paymentMethods: [{ paymentMethodType: 'paypal', accountId: 'acc1' }] };

function makeRequest(
    fields: Record<string, string> = {
        basketId: 'b1',
        shippingAddress: JSON.stringify(ADDRESS),
        labels: JSON.stringify(LABELS),
        paymentMethodType: 'paypal',
        paymentConfig: JSON.stringify(PAYMENT_CONFIG),
    },
    method = 'POST'
) {
    const form = new FormData();
    for (const [k, v] of Object.entries(fields)) form.set(k, v);
    const canHaveBody = method !== 'GET' && method !== 'HEAD';
    return new Request('https://shop.example/action/sf-payments-update-shipping-address', {
        method,
        ...(canHaveBody && { body: form }),
    });
}

beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(updateShippingAddressForShipment).mockResolvedValue(BASKET_AFTER as never);
    vi.mocked(getShippingMethodsForShipment).mockResolvedValue(METHODS as never);
    vi.mocked(validateAndUpdateShippingMethod).mockResolvedValue(BASKET_AFTER as never);
});

describe('action.sf-payments-update-shipping-address', () => {
    test('skips PATCH PI when no SF Payments instrument is attached', async () => {
        const result = (await action({
            request: makeRequest(),
            context: mockContext,
            params: {},
        } as any)) as { success: boolean };

        expect(patchPaymentInstrumentOnBasket).not.toHaveBeenCalled();
        expect(result.success).toBe(true);
    });

    test('PATCHes the SF Payments PI when attached', async () => {
        const basketWithPI = {
            ...BASKET_AFTER,
            paymentInstruments: [{ paymentMethodId: 'Salesforce Payments', paymentInstrumentId: 'pi1', amount: 100 }],
        };
        vi.mocked(validateAndUpdateShippingMethod).mockResolvedValue(basketWithPI as never);
        vi.mocked(patchPaymentInstrumentOnBasket).mockResolvedValue(basketWithPI as never);

        const result = (await action({
            request: makeRequest(),
            context: mockContext,
            params: {},
        } as any)) as { success: boolean };

        expect(patchPaymentInstrumentOnBasket).toHaveBeenCalledWith(
            mockContext,
            'b1',
            'pi1',
            expect.objectContaining({ paymentMethodId: 'Salesforce Payments' })
        );
        expect(result.success).toBe(true);
    });

    test('returns gateway_sync_failed when PATCH PI fails', async () => {
        const basketWithPI = {
            ...BASKET_AFTER,
            paymentInstruments: [{ paymentMethodId: 'Salesforce Payments', paymentInstrumentId: 'pi1', amount: 100 }],
        };
        vi.mocked(validateAndUpdateShippingMethod).mockResolvedValue(basketWithPI as never);
        vi.mocked(patchPaymentInstrumentOnBasket).mockRejectedValue(new Error('boom'));

        const result = await action({
            request: makeRequest(),
            context: mockContext,
            params: {},
        } as any);

        expect(dataOf(result)).toEqual({ success: false, error: 'gateway_sync_failed' });
    });
});
