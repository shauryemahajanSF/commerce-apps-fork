/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import CartExpressButtons from './index';
import { EXPRESS_PAY_NOW } from '../../lib/sf-payments-utils';

// Mock dependencies
vi.mock('@salesforce/storefront-next-runtime/site-context', () => ({
    useSite: vi.fn(),
}));

vi.mock('@/providers/basket', () => ({
    useBasket: vi.fn(),
}));

vi.mock('../express-buttons', () => ({
    default: vi.fn(() => <div data-testid="express-buttons-mock">ExpressButtons</div>),
}));

vi.mock('../../lib/sf-payments-country', () => ({
    getLocaleDerivedCountryCode: vi.fn(() => 'US'),
}));

import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import { useBasket } from '@/providers/basket';
import ExpressButtons from '../express-buttons';
import { getLocaleDerivedCountryCode } from '../../lib/sf-payments-country';

describe('CartExpressButtons', () => {
    const mockBasket = {
        basketId: 'test-basket-123',
        currency: 'USD',
        orderTotal: 149.99,
        productTotal: 149.99,
        billingAddress: {
            countryCode: 'US',
        },
    };

    const mockSite = {
        locale: { id: 'en-US' },
        currency: 'USD',
    };

    beforeEach(() => {
        vi.clearAllMocks();
        (useSite as any).mockReturnValue(mockSite);
        (useBasket as any).mockReturnValue(mockBasket);
    });

    it('renders express buttons when basket exists', () => {
        render(<CartExpressButtons />);

        expect(screen.getByTestId('cart-express-buttons-wrapper')).toBeInTheDocument();
        expect(screen.getByTestId('express-buttons-mock')).toBeInTheDocument();
    });

    it('returns null when no basket available', () => {
        (useBasket as any).mockReturnValue(null);

        const { container } = render(<CartExpressButtons />);

        expect(container.firstChild).toBeNull();
    });

    it('passes correct props to ExpressButtons component', () => {
        render(<CartExpressButtons />);

        const callArgs = (ExpressButtons as any).mock.calls[0][0];
        expect(callArgs).toMatchObject({
            initialAmount: 149.99,
            currency: 'USD',
            countryCode: 'US',
            usage: EXPRESS_PAY_NOW,
            expressButtonLayout: 'vertical',
            maximumButtonCount: 4,
        });
        expect(callArgs.prepareBasket).toBeInstanceOf(Function);
    });

    it('uses billing address country code when available', () => {
        render(<CartExpressButtons />);

        const callArgs = (ExpressButtons as any).mock.calls[0][0];
        expect(callArgs.countryCode).toBe('US');
    });

    it('falls back to locale-derived country when no billing address', () => {
        (useBasket as any).mockReturnValue({
            ...mockBasket,
            billingAddress: undefined,
        });

        render(<CartExpressButtons />);

        expect(getLocaleDerivedCountryCode).toHaveBeenCalledWith('en-US');
        const callArgs = (ExpressButtons as any).mock.calls[0][0];
        expect(callArgs.countryCode).toBe('US');
    });

    it('uses productTotal as fallback when orderTotal is undefined', () => {
        (useBasket as any).mockReturnValue({
            ...mockBasket,
            orderTotal: undefined,
            productTotal: 99.99,
        });

        render(<CartExpressButtons />);

        const callArgs = (ExpressButtons as any).mock.calls[0][0];
        expect(callArgs.initialAmount).toBe(99.99);
    });

    it('passes prepareBasket callback that returns the basket', async () => {
        render(<CartExpressButtons />);

        const prepareBasketCall = (ExpressButtons as any).mock.calls[0][0];
        const prepareBasket = prepareBasketCall.prepareBasket;

        const result = await prepareBasket();

        expect(result).toBe(mockBasket);
    });

    it('prepareBasket throws error when basket is null', async () => {
        // Start with null basket
        (useBasket as any).mockReturnValue(null);

        // Component won't render when basket is null, so we need to test prepareBasket
        // in the scenario where the basket becomes null during payment processing
        const TestComponent = () => {
            const basket = useBasket();
            const prepareBasket = () => {
                if (!basket) {
                    return Promise.reject(new Error('No basket available'));
                }
                return Promise.resolve(basket);
            };
            // Expose prepareBasket for testing
            (window as any).testPrepareBasket = prepareBasket;
            return null;
        };

        render(<TestComponent />);

        await expect((window as any).testPrepareBasket()).rejects.toThrow('No basket available');
    });
});
